import type { DesignerElement } from "../components/designer/DesignerTypes";

export interface Template {

  id: number;

  name: string;

  elements: DesignerElement[];

}

const STORAGE_KEY = "templates";

/* ========================= */
/* Obtener todas las plantillas */
/* ========================= */

export function getTemplates(): Template[] {

  const data = localStorage.getItem(STORAGE_KEY);

  if (!data) return [];

  return JSON.parse(data);

}

/* ========================= */
/* Guardar todas */
/* ========================= */

export function saveTemplates(templates: Template[]) {

  localStorage.setItem(
    STORAGE_KEY,
    JSON.stringify(templates)
  );

}

/* ========================= */
/* Añadir */
/* ========================= */

export function addTemplate(template: Template) {

  const templates = getTemplates();

  templates.push(template);

  saveTemplates(templates);

}

/* ========================= */
/* Actualizar */
/* ========================= */

export function updateTemplate(template: Template) {

  const templates = getTemplates().map(t =>

    t.id === template.id
      ? template
      : t

  );

  saveTemplates(templates);

}

/* ========================= */
/* Eliminar */
/* ========================= */

export function deleteTemplate(id: number) {

  console.log("========== ELIMINAR ==========");

  console.log("ID recibido:", id);

  const templates = getTemplates();

  console.log("Plantillas antes:", templates);

  const filtered = templates.filter(
    t => t.id !== id
  );

  console.log("Plantillas después:", filtered);

  saveTemplates(filtered);

  console.log("Guardadas correctamente.");

}

/* ========================= */
/* Buscar */
/* ========================= */

export function findTemplate(id: number) {

  return getTemplates().find(
    t => t.id === id
  );

}

/* ========================= */
/* Plantilla abierta */
/* ========================= */

const CURRENT_TEMPLATE = "currentTemplate";

export function setCurrentTemplate(id: number) {

  localStorage.setItem(
    CURRENT_TEMPLATE,
    id.toString()
  );

}

export function getCurrentTemplate() {

  const value = localStorage.getItem(CURRENT_TEMPLATE);

  if (!value) return null;

  return Number(value);

}

export function clearCurrentTemplate() {

  localStorage.removeItem(CURRENT_TEMPLATE);

}