import { useEffect, useState } from "react";

import {
  Box,
  Button,
  Card,
  CardContent,
  Stack,
  Typography
} from "@mui/material";

import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";

import { useNavigate } from "react-router-dom";

import type { Template } from "../../services/TemplateStorage";

import {
  getTemplates,
  saveTemplates,
  deleteTemplate,
  setCurrentTemplate
} from "../../services/TemplateStorage";

export default function Templates() {

  const navigate = useNavigate();

  const [templates, setTemplates] = useState<Template[]>([]);

  useEffect(() => {
    loadTemplates();
  }, []);

  function loadTemplates() {
    setTemplates(getTemplates());
  }

  function openTemplate(template: Template) {
    setCurrentTemplate(template.id);
    navigate("/templates/designer");
  }

  function newTemplate() {
    setCurrentTemplate(0);
    navigate("/templates/designer");
  }

  function remove(id: number) {

    if (!window.confirm("¿Eliminar esta plantilla?")) return;

    deleteTemplate(id);

    loadTemplates();

  }

  function duplicate(template: Template) {

    const list = getTemplates();

    list.push({
      ...template,
      id: Date.now(),
      name: template.name + " (Copia)"
    });

    saveTemplates(list);

    loadTemplates();

  }

  return (

    <Box>

      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        mb={3}
      >

        <Typography
          variant="h4"
          fontWeight="bold"
        >

          Plantillas

        </Typography>

        <Button
          variant="contained"
          color="success"
          onClick={newTemplate}
        >

          Nueva plantilla

        </Button>

      </Stack>

      <Stack spacing={2}>

        {templates.length === 0 && (

          <Typography>

            No hay plantillas guardadas.

          </Typography>

        )}

        {templates.map(template => (

          <Card
            key={template.id}
          >

            <CardContent>

              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >

                <Box>

                  <Typography variant="h6">
                    {template.name}
                  </Typography>

                  <Typography color="text.secondary">
                    {template.elements.length} elementos
                  </Typography>

                </Box>

                <Stack
                  direction="row"
                  spacing={1}
                >

                  <Button
                    startIcon={<EditIcon />}
                    variant="contained"
                    onClick={() => openTemplate(template)}
                  >
                    Editar
                  </Button>

                  <Button
                    startIcon={<ContentCopyIcon />}
                    variant="outlined"
                    onClick={() => duplicate(template)}
                  >
                    Duplicar
                  </Button>

                  <Button
                    startIcon={<DeleteIcon />}
                    color="error"
                    variant="outlined"
                    onClick={() => remove(template.id)}
                  >
                    Eliminar
                  </Button>

                </Stack>

              </Stack>

            </CardContent>

          </Card>

        ))}

      </Stack>

    </Box>

  );

}